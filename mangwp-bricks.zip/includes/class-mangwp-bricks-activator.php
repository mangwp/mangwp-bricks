<?php

/**
 * Fired during plugin activation
 *
 * @link       https://mangwp.com
 * @since      1.0.0
 *
 * @package    Mangwp_Bricks
 * @subpackage Mangwp_Bricks/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Mangwp_Bricks
 * @subpackage Mangwp_Bricks/includes
 * @author     Ivan Nugraha <ivan@mangwp.com>
 */
class Mangwp_Bricks_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
